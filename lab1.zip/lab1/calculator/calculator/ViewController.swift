//
//  ViewController.swift
//  calculator
//
//  Created by SOCD on 5/27/21.
//  Copyright © 2021 SOCD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   

    @IBOutlet weak var lblNumberShow: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var newOperation = true
    func AddnumberToInput(number: String) {
        var textNumber = String(lblNumberShow.text!)
        
        if newOperation {
            textNumber = ""
            newOperation = false
        }
        textNumber = textNumber + number
        lblNumberShow.text = textNumber
    }
    
    @IBAction func btnO(_ sender: Any) {
        AddnumberToInput(number: "0")
    }
    
    @IBAction func btn1(_ sender: Any) {
        AddnumberToInput(number: "1")
    }
    
    
    @IBAction func btn2(_ sender: Any) {
        AddnumberToInput(number: "2")
    }
    
    
    @IBAction func btn3(_ sender: Any) {
        AddnumberToInput(number: "3")
    }
    
    @IBAction func btn4(_ sender: Any) {
        AddnumberToInput(number: "4")
    }
    
    @IBAction func btn5(_ sender: Any) {
        AddnumberToInput(number: "5")
    }
    
    @IBAction func btn6(_ sender: Any) {
        AddnumberToInput(number: "6")
    }
    
    @IBAction func btn7(_ sender: Any) {
        AddnumberToInput(number: "7")
    }
    
    @IBAction func btn8(_ sender: Any) {
        AddnumberToInput(number: "8")
    }
    
    @IBAction func btn9(_ sender: Any) {
        AddnumberToInput(number: "9")
    }
    
    var op = "+"
    var number1:Double?
    @IBAction func btnMult(_ sender: Any) {
        op = "*"
        number1 = Double(lblNumberShow.text!)
        newOperation = true
    }
    
    @IBAction func btnDiv(_ sender: Any) {
        op = "/"
        number1 = Double(lblNumberShow.text!)
        newOperation = true
    }
    
    @IBAction func btnSub(_ sender: Any) {
        op = "-"
        number1 = Double(lblNumberShow.text!)
        newOperation = true
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        op = "+"
        number1 = Double(lblNumberShow.text!)
        newOperation = true
    }
    
    @IBAction func btnClear(_ sender: Any) {
        lblNumberShow.text = "0"
        newOperation = true
    }
    
    @IBAction func btnPM(_ sender: Any) {
        var textNumber = String(lblNumberShow.text!)
        textNumber = "-" + textNumber
        lblNumberShow.text = textNumber
    }
    
    @IBAction func btnPercent(_ sender: Any) {
        var number1 = Double(lblNumberShow.text!)
        number1 = number1!/100
        lblNumberShow.text = String(number1!)
        newOperation = true 
    }
    
    
    
    @IBAction func btnEqual(_ sender: Any) {
        let number2 = Double(lblNumberShow.text!)
        var result:Double?
        switch op {
        case "*":
            result = number1! * number2!
        case "/":
            result = number1! / number2!
        case "-":
            result = number1! - number2!
        case "+":
            result = number1! + number2!
        default:
            result = 0.0
        }
        lblNumberShow.text = String(result!)
        newOperation = true
    }
    
}

